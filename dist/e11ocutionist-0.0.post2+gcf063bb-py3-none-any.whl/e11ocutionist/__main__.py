#!/usr/bin/env python3
# this_file: src/e11ocutionist/__main__.py
"""Main entry point for e11ocutionist package."""

from .cli import main

if __name__ == "__main__":
    main()
